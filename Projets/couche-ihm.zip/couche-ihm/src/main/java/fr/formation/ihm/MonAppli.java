package fr.formation.ihm;

import fr.formation.metier.PersonneService;
import fr.formation.repository.PersonneRepository;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.ResourceBundle;

public class MonAppli {

    public static void main(String[] args) throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, InstantiationException, IllegalAccessException {

        ResourceBundle rb = ResourceBundle.getBundle("data");
        String classeAInjecter = rb.getString("impl");
        Class monImpl = Class.forName(classeAInjecter);

        Constructor constr = monImpl.getConstructor();

        Object instance = constr.newInstance();

        PersonneService personneService = new PersonneService((PersonneRepository) instance);

        personneService.listerPersonnes();
    }
}
