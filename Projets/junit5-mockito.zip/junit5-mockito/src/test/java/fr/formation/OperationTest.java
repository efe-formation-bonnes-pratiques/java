package fr.formation;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;


@ExtendWith(MockitoExtension.class)
public class OperationTest {

    @Mock
    private Operation operation;

    @Test
    void testCreationMock(){
        Operation op = Mockito.mock(Operation.class);
        Assertions.assertFalse(op == null);
        System.out.println(op);
    }

    @Test
    void testCreationMockAvecParametre(){
        Operation op = Mockito.mock(Operation.class, "Mon mock");
        Assertions.assertFalse(op == null);
        System.out.println(op);
    }

    @Test
    void testMockInjecte(){
        Assertions.assertFalse(operation == null);
        System.out.println(operation);
    }

    @Test
    void testAddition(){
        Assertions.assertEquals(0, operation.addition(20, 22));
    }

    @Test
    void testDivisionParZero(){
        Assertions.assertEquals(0, operation.division(0, 0));
    }

    @Test
    void testAdditionStubb(){
        Mockito.when(operation.addition(20, 22)).thenReturn(42);

        Assertions.assertEquals(0, operation.addition(10, 12));
        Assertions.assertEquals(42, operation.addition(20, 22));
        Assertions.assertEquals(0, operation.addition(22, 20));
        Assertions.assertEquals(42, operation.addition(20, 22));
        Assertions.assertEquals(42, operation.addition(20, 22));
        Assertions.assertEquals(42, operation.addition(20, 22));
        Assertions.assertEquals(42, operation.addition(20, 22));
    }

    @Test
    void testDivisionParZeroAvecStub(){
        Mockito.when(operation.division(Mockito.anyInt(), Mockito.eq(0))).thenThrow(RuntimeException.class);

        Assertions.assertThrows(RuntimeException.class, () -> operation.division(0, 0));
        Assertions.assertThrows(RuntimeException.class, () -> operation.division(10, 0));
        Assertions.assertThrows(RuntimeException.class, () -> operation.division(-410, 0));
    }


    @Test
    void testGetRandomInt(){
        Mockito.when(operation.getRandomInt()).thenReturn(-1, 6, 45, -708, 23);
        Assertions.assertEquals(-1, operation.getRandomInt());
        Assertions.assertEquals(6, operation.getRandomInt());
        Assertions.assertEquals(45, operation.getRandomInt());
        Assertions.assertEquals(-708, operation.getRandomInt());
        Assertions.assertEquals(23, operation.getRandomInt());
        Assertions.assertEquals( 23 , operation.getRandomInt());
        Assertions.assertEquals( 23 , operation.getRandomInt());
        Assertions.assertEquals( 23 , operation.getRandomInt());
   //     Assertions.assertEquals( 23 , operation.getRandomInt());

        Mockito.verify(operation, Mockito.times(8)).getRandomInt();
    }

    @Test
    void testGetRandomIntList(){
        int nb = 7;
        OperationImpl opImp = new OperationImpl();

        Operation spyOp = Mockito.spy(opImp);

        List<Integer> liste = spyOp.getRandomIntList(nb);
        Assertions.assertEquals(nb, liste.size());

        Mockito.verify(spyOp, Mockito.times(nb)).getRandomInt();
    }
}
