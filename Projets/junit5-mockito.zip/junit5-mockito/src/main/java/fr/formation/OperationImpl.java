package fr.formation;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class OperationImpl implements Operation {
    @Override
    public int addition(int a, int b) {
        return a + b;
    }

    @Override
    public int soustraction(int a, int b) {
        return a - b;
    }

    @Override
    public int multiplication(int a, int b) {
        return a * b;
    }

    @Override
    public int division(int a, int b) throws RuntimeException {
        if (b == 0)
            throw new RuntimeException();
        return a / b;
    }

    @Override
    public int getRandomInt() {
        return new Random().nextInt(100);
    }

    @Override
    public List<Integer> getRandomIntList(int nb) {
        List<Integer> liste= new ArrayList<>();
        for(int i = 0 ; i < nb ; i++){
            liste.add(getRandomInt());
        }
        return liste;
    }
}
