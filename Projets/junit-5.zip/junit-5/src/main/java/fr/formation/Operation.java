package fr.formation;

import fr.formation.exception.OperationException;

public class Operation {

    public int addition(int a, int b){
        return a + b;
    }

    public double soustraction(double a, double b){
        return a - b;
    }

    public int multiplication(int a, int b){
        return a * b;
    }

    public int division(int a, int b) throws OperationException {
        if (b == 0)
            throw new OperationException("Attention, division par zero");
        return a / b;
    }

}
