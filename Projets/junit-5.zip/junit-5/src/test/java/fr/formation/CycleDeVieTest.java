package fr.formation;

import org.junit.jupiter.api.*;

public class CycleDeVieTest {


    @BeforeAll // @BeforeClass junit4
    static void beforeAll(){
        System.out.println("beforeAll");
    }

    @BeforeEach // @Before junit4
    void beforeEach(){
        System.out.println("    beforeEach");
    }

    @AfterEach
    void afterEach(){
        System.out.println("    afterEach");
    }

    @AfterAll
    static void afterAll(){
        System.out.println("afterAll");
    }


    @Test
    void test1(){
        System.out.println("        test1");
    }

    @Test
    void test2(){
        System.out.println("        test2");
    }

    @Test
    void test3(){
        System.out.println("        test3");
    }
}
