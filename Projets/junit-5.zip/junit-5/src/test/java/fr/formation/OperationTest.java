package fr.formation;

import fr.formation.exception.OperationException;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OperationTest {

    // Run :
    // Demander au Runner principal de JUNIT (contient un main) de prendre en parametre
    // la classe OperationTest pour effectuer les tests unitaires
    // Etude de la classe -> quelles sont les methodes a tester
    // Boucler sur
    // instance de la classe de test puis appel d'une methode de test

    private static Operation op;

    @BeforeEach
    void initAvantTest(){
  //      op = new Operation();
    }

    @BeforeAll
    static void initAvantTousLesTests(){
        op = new Operation();
    }



    @Test
    void testAddition() {
        // GIVEN
        int a = 14;
        int b = 26;
        int resultatAttendu = 40;


        // WHEN
        int resultatReel = op.addition(a, b);

        // THEN
         assertEquals(resultatAttendu, resultatReel, () -> "L'addition' : " +a + " + " +b + " devrait être égal à "
                 + resultatAttendu + " mais est egal à " + resultatReel);
    }

    @Test
    void testSoustraction(){
        double a = 6.1;
        double b = 2.1;
        double attendu = 4.0;


        double real = op.soustraction(a, b);
        assertEquals(attendu, real, 0.00001, () -> "La soustraction : " +a + " - " +b + " devrait être égale à "
         + attendu + " mais est egale à " + real);
    }

    @Test
    void testDivisionParZero() throws OperationException {
        OperationException oe = assertThrows(OperationException.class, () -> op.division(45, 0));
        assertTrue(oe.getMessage().contains("division par zero"));
    }

    @Test
    void testDivisionPasParZero(){
        assertDoesNotThrow( () -> op.division(4, 6));
    }
}
