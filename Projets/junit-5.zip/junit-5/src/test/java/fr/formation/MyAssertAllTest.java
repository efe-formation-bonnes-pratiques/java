package fr.formation;

import fr.formation.model.Personne;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class MyAssertAllTest {


    @Test
    void testPersonneJunit4(){
        Personne real = new Personne("Lepetit", "Jack", 55);
        Personne expected = new Personne("Legrand", "Joe", 44);


        Assertions.assertEquals(expected.getNom(), real.getNom());
        Assertions.assertEquals(expected.getPrenom(), real.getPrenom());
        Assertions.assertEquals(expected.getAge(), real.getAge());

    }


    @Test
    void testPersonneJunit5(){
        Personne real = new Personne("Legrand", "Joe", 44);
        Personne expected = new Personne("Legrand", "Joe", 44);

        Assertions.assertAll(
                () -> Assertions.assertEquals(expected.getNom(), real.getNom()),
                () -> Assertions.assertEquals(expected.getPrenom(), real.getPrenom()),
                () -> Assertions.assertEquals(expected.getAge(), real.getAge())
        );


    }
}
