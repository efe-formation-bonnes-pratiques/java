package fr.formation.model;


import lombok.*;

import java.time.LocalDate;
import java.util.Objects;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@ToString(of = {"auteur", "titre"})
@EqualsAndHashCode(of = {"titre", "auteur", "nbPages"})
@Builder
public class Livre {

    private String titre;
    private String auteur;
    private int nbPages;

    private boolean lu;

    public String getTitre() {
        return "titre changé " + titre;
    }
}
