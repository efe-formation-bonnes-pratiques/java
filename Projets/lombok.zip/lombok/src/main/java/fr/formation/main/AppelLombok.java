package fr.formation.main;

import fr.formation.model.Livre;

public class AppelLombok {
    public static void main(String[] args) {

        Livre l1 = new Livre("Camus", "L'étranger", 322, true);
        Livre l2 = new Livre();

        l2.setAuteur("Baudelaire");
        l2.setTitre("Les fleurs du mal");
        l2.setNbPages(666);
        l2.setLu(false);


        System.out.println(l1.getTitre());

        System.out.println(l1);

        Livre l3 = new Livre("Camus", "L'étranger", 322, false);

        System.out.println(l1.equals(l3));

        Livre l4 = Livre
                .builder()
                .titre("Ma vie")
                .auteur("Charles")
                .nbPages(321)
                .build();
        System.out.println(l4);


    }
}
