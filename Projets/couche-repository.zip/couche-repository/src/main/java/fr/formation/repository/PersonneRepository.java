package fr.formation.repository;



import fr.formation.Personne;

import java.util.List;

public interface PersonneRepository {

    void add(Personne p);
    List<Personne> findAll();
}
