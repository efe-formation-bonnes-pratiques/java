package fr.formation.repository;

import fr.formation.Personne;

import java.util.List;

public class PersonneRepositoryImplExcel implements PersonneRepository{
    @Override
    public void add(Personne p) {
        System.out.println("Ajout dans un fichier Excel");

    }

    @Override
    public List<Personne> findAll() {
        System.out.println("Recherche dans un fichier Excel");
        return null;
    }
}
