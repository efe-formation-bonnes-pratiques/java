package fr.formation.repository;

import fr.formation.Personne;

import java.util.List;

public class PersonneRepositoryImplJdbc implements PersonneRepository {
    @Override
    public void add(Personne p) {
        System.out.println("Ajout dans la base de données");
    }

    @Override
    public List<Personne> findAll() {
        System.out.println("Recherche dans la base de données");
        return null;
    }
}
