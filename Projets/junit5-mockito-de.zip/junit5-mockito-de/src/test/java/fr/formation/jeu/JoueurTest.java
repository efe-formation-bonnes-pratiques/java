package fr.formation.jeu;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.mockito.Mockito;

import java.util.Random;

public class JoueurTest {

    // play
    // Le dé est lancé 2 fois
    // si 1er lancer > 2eme -> 1er lancer qui est gardé
    // si 1er lancer < 2eme -> 2eme lancer qui est gardé
    // si 1er lancer = 2eme -> 2eme lancer qui est gardé

    // getLastValue
    // si joueur joue -> contenu existe
    // si joueur ne joue pas -> pas de contenu


    @Test
    void testPasDeContenuSiJoueurJouePas(){
        Joueur j = new Joueur("J1", new De(new Random()));
        Assertions.assertFalse(j.getLastValue().isPresent());
    }

    @Test
    void testContenuSiJoueurJoue(){
        Joueur j = new Joueur("J1", new De(new Random()));
        j.play();
        Assertions.assertTrue(j.getLastValue().isPresent());
    }

    @Test
    void testLancerDeuxFois(){
        De mockDe = Mockito.mock(De.class);
        Joueur j = new Joueur("J", mockDe);
        j.play();
        Mockito.verify(mockDe, Mockito.times(2)).lancer();
    }

    @ParameterizedTest
    @CsvSource(value = {"5,3,5", "2,6,6", "4,4,4"})
    void testRenvoieValeurPlusGrande(int a, int b, int attendu){
        De mockDe = Mockito.mock(De.class);
        Mockito.when(mockDe.lancer()).thenReturn(a, b);
        Joueur j = new Joueur("J", mockDe);
        j.play();
        Assertions.assertEquals(attendu, j.getLastValue().get().get());
    }
/*
    @Test
    void testRenvoiePremierValeurSiPlusGrande(){
        De mockDe = Mockito.mock(De.class);
        Mockito.when(mockDe.lancer()).thenReturn(5, 3);
        Joueur j = new Joueur("J", mockDe);
        j.play();
        Assertions.assertEquals(5, j.getLastValue().get().get());
    }

    @Test
    void testRenvoieDeuxiemeValeurSiPlusGrande(){
        De mockDe = Mockito.mock(De.class);
        Mockito.when(mockDe.lancer()).thenReturn(2, 6);
        Joueur j = new Joueur("J", mockDe);
        j.play();
        Assertions.assertEquals(6, j.getLastValue().get().get());
    }

    @Test
    void testRenvoieMemeValeurSiPlusGrande(){
        De mockDe = Mockito.mock(De.class);
        Mockito.when(mockDe.lancer()).thenReturn(4, 4);
        Joueur j = new Joueur("J", mockDe);
        j.play();
        Assertions.assertEquals(4, j.getLastValue().get().get());
    }
*/
}
