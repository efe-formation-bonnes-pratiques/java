package fr.formation.jeu;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ResultatTest {

    // A tester :

    // compareTo
    // equals
    // get
    //      NON : getter, get est utilisé dans equals
    //      OUI : pas un getter, 0% classe 100% classe

    private Resultat r3;
    private Resultat r5;
    private Resultat r5bis;

    @BeforeEach
    void init(){
        r3 = new Resultat(3);
        r5 = new Resultat(5);
        r5bis = new Resultat(5);
    }



    @Test
    void testCompareToRenvoieMoins1(){
        Assertions.assertTrue(r3.compareTo(r5) < 0);
    }

    @Test
    void testCompareToRenvoiePlus1(){
        Assertions.assertTrue(r5.compareTo(r3) > 0);
    }

    @Test
    void testCompareToRenvoie0(){
        Assertions.assertEquals(0, r5bis.compareTo(r5));
    }

    @Test
    void testEqualsPasMemeType(){
        Assertions.assertFalse(r3.equals("Hello"));
    }

    @Test
    void testEqualsMemesValeurs(){
        Assertions.assertTrue(r5.equals(r5bis));
    }

    @Test
    void testEqualsValeursDifferentes(){
        Assertions.assertFalse(r3.equals(r5));
    }

    @Test
    void testEqualsNull(){
        Assertions.assertFalse(r3.equals(null));
    }


}
