package fr.formation.jeu;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.RepeatedTest;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.*;

@ExtendWith(MockitoExtension.class)
public class DeTest {

    // tests a effectuer :
    // lancer()
    // 1. Verifier que plusieurs lancers consecutifs ne revoient pas la même valeur
    // 2. Verifier que FACES = 6
    // 3. Vérifier que les valeurs sont entre 1 et FACES (6)
    // 4. si resultat < 1 -> RuntimeException
    // 4bis. si resultat > FACES -> RuntimeException

    @Mock
    private Random randomMock;

    @InjectMocks
    private De mockDe;

    @Captor
    ArgumentCaptor<Integer> argumentCaptor;


    @Test
    @DisplayName("Plusieurs lancers consecutifs ne revoient pas la même valeur")
    void testLancerConsecutifsPasMemeValeur(){
        De leDe = new De(new Random());
        Set<Integer> listeI = new HashSet<>();
        for(int i = 0 ; i < 1000 ; i++){
            listeI.add(leDe.lancer());
        }
        Assertions.assertTrue(listeI.size() > 1);
    }

    @Test
    @DisplayName("Verifier que FACES = 6")
    void testFacesEgal6(){

        mockDe.lancer();
        Mockito.verify(randomMock).nextInt(argumentCaptor.capture());
        Assertions.assertEquals(6, argumentCaptor.getValue());
    }

    @RepeatedTest(100)
    @DisplayName("Les valeurs sont entre 1 et 6")
    void testValeursEntre1Et6(){
        De leDe = new De(new Random());
        int value = leDe.lancer();

        Assertions.assertAll(
                () -> Assertions.assertTrue(value <= 6),
                () -> Assertions.assertTrue(value >= 1)
        );
    }
/*
    @Test
    @DisplayName("Renvoie une RuntimeException si valeur < 1")
    void testExceptionSiInf1(){
        Mockito.when(randomMock.nextInt(Mockito.anyInt())).thenReturn(-14);
        De leDe = new De(randomMock);
        RuntimeException re = Assertions.assertThrows(RuntimeException.class, () -> leDe.lancer());
        Assertions.assertTrue(re.getMessage().contains("incompatible"));
    }

    @Test
    @DisplayName("Renvoie une RuntimeException si valeur > 6")
    void testExceptionSiSup6(){
        Mockito.when(randomMock.nextInt(Mockito.anyInt())).thenReturn(12);
        De leDe = new De(randomMock);
        RuntimeException re = Assertions.assertThrows(RuntimeException.class, () -> leDe.lancer());
        Assertions.assertTrue(re.getMessage().contains("incompatible"));
    }

*/
    @ParameterizedTest
    @ValueSource(ints ={-14, 12})
    @DisplayName("Renvoie une RuntimeException si valeur > 6 ou valeur < 1")
    void testExceptionSiSup6OuInf1(int valeur){
        Mockito.when(randomMock.nextInt(Mockito.anyInt())).thenReturn(valeur);
        De leDe = new De(randomMock);
        RuntimeException re = Assertions.assertThrows(RuntimeException.class, () -> leDe.lancer());
        Assertions.assertTrue(re.getMessage().contains("incompatible"));
    }


}
