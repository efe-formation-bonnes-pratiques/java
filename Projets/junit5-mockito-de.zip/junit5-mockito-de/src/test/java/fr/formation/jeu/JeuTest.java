package fr.formation.jeu;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.util.Optional;

public class JeuTest {

    // jouer
    // Si gauche a un meilleur lancer que droit -> gauche gagne
    // Si droit a un meilleur lancer que gauche -> droit gagne
    // Si au bout de 5 echanges match nul -> Pas de gagnant

    Joueur gauche;
    Joueur droit;
    Jeu jeu;

    @Test
    void testGaucheGagne(){
        gauche = Mockito.mock(Joueur.class);
        Resultat resG = new Resultat(5);
        Optional<Resultat> opResG = Optional.of(resG);
        Mockito.when(gauche.getLastValue()).thenReturn(opResG);

        droit = Mockito.mock(Joueur.class);
        Resultat resD = new Resultat(3);
        Optional<Resultat> opResD = Optional.of(resD);
        Mockito.when(droit.getLastValue()).thenReturn(opResD);

        jeu = new Jeu(gauche, droit);
        Optional<Joueur> optJ = jeu.jouer();

        Assertions.assertTrue(optJ.isPresent());
        Assertions.assertEquals(gauche, optJ.get());
    }

    @Test
    void testDroitGagne(){
        gauche = Mockito.mock(Joueur.class);
        Resultat resG = new Resultat(1);
        Optional<Resultat> opResG = Optional.of(resG);
        Mockito.when(gauche.getLastValue()).thenReturn(opResG);

        droit = Mockito.mock(Joueur.class);
        Resultat resD = new Resultat(4);
        Optional<Resultat> opResD = Optional.of(resD);
        Mockito.when(droit.getLastValue()).thenReturn(opResD);

        jeu = new Jeu(gauche, droit);
        Optional<Joueur> optJ = jeu.jouer();

        Assertions.assertTrue(optJ.isPresent());
        Assertions.assertEquals(droit, optJ.get());
    }

    @Test
    void testEgalite(){
        // si le dé renvoie toujours 5
        De mockDe = Mockito.mock(De.class);
        Mockito.when(mockDe.lancer()).thenReturn(5);

        gauche = new Joueur("gauche", mockDe);
        droit = new Joueur("droit", mockDe);

        Joueur spyG = Mockito.spy(gauche);
        Joueur spyD = Mockito.spy(droit);

        jeu = new Jeu(spyG, spyD);

        Optional<Joueur> optJ = jeu.jouer();
        Assertions.assertFalse(optJ.isPresent());

        // Verifier gauche et droit ont 5x play()
        Mockito.verify(spyG, Mockito.times(5)).play();
        Mockito.verify(spyD, Mockito.times(5)).play();
    }


}
