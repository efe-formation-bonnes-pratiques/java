package fr.formation;

public class Personne {
	private String nom;
    private String prenom;
    private int age;
    
    
	@Override
	public String toString() {
		return "Personne [nom=" + nom + ", prenom=" + prenom + ", age=" + age + "]";
	}
    
    
}
