package fr.formation;

import java.lang.reflect.Field;

public class MaRefelexion {

	public static void main(String[] args) throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
		
		Field privateNom = Personne.class.getDeclaredField("nom");
		Field privatePrenom = Personne.class.getDeclaredField("prenom");
		Field privateAge = Personne.class.getDeclaredField("age");
		
		privateNom.setAccessible(true);
		privatePrenom.setAccessible(true);
		privateAge.setAccessible(true);
		
		Personne p = new Personne();
		privateNom.set(p, "Lemoyen");
		privatePrenom.set(p, "Joe");
		privateAge.set(p, 33);
		
		System.out.println(p);
	}
}
