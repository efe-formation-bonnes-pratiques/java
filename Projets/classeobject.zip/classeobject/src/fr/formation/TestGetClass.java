package fr.formation;

import fr.formation.model.Personne;

public class TestGetClass {
    public static void main(String[] args) {
        Personne p1 = new Personne("Legrand", "Joe", 44);
        Personne p2 = new Personne("Lepetit", "Jack", 55);

        Class c = p1.getClass();
        Class c2 = p2.getClass();

        System.out.println(p1 instanceof Object);

        System.out.println(c == c2);
        System.out.println("c = " + c);
        System.out.println("c.getName() = " + c.getName());
        System.out.println("c.getPackage() = " + c.getPackage());

    }
}
