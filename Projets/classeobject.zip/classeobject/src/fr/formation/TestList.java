package fr.formation;

import fr.formation.model.Personne;

import java.util.ArrayList;
import java.util.List;

public class TestList {
    public static void main(String[] args) {

        Personne p1 = new Personne("Legrand", "Joe", 44);
        Personne p2 = new Personne("Lepetit", "Suzon", 30);
        Personne p3 = new Personne("Lemoyen", "Anne", 55);

        List<Personne> listeP = new ArrayList<>();
        listeP.add(p1);
        listeP.add(p2);
        listeP.add(p3);

        // 1 : for
        for (int i = 0 ; i < listeP.size(); i++){
            System.out.println(listeP.get(i));
        }

        // 2 : foreach
        for (Personne p : listeP){
            System.out.println(p);
        }

        // 3 : Java 8
        listeP.forEach(System.out::println);
    }
}
