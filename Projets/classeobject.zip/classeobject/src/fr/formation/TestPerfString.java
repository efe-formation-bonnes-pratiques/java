package fr.formation;

public class TestPerfString {

    public static void main(String[] args) {

        String chaine = "";
        long debut = System.currentTimeMillis();
        for (int i = 0; i < 300000 ; i++){
            chaine += "s";
        }
        long fin = System.currentTimeMillis();
        System.out.println("Duree concat avec String : " + (fin - debut) + " ms");

        StringBuilder sb = new StringBuilder();

        debut = System.currentTimeMillis();
        for (int i = 0; i < 300000 ; i++){
            sb.append("s");
        }
        fin = System.currentTimeMillis();
        System.out.println("Duree concat avec StringBuilder : " + (fin - debut) + " ms");
    }
}
