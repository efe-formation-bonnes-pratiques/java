package fr.formation.model;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Vector;

public class Personne implements Cloneable, Comparable<Personne>{
    private String nom;
    private String prenom;
    private int age;

    public Personne(String nom, String prenom, int age) {
        this.nom = nom;
        this.prenom = prenom;
        this.age = age;
    }

    public Personne(Personne p) {
        this.nom = p.nom;
        this.prenom = p.prenom;
        this.age = p.age;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        Personne personne = (Personne) o;
        return age == personne.age && Objects.equals(nom, personne.nom) && Objects.equals(prenom, personne.prenom);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nom, prenom, age);
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }


    //    @Override
//    public boolean equals(Object o) {
//        boolean result = true;
//
//        if (this != o){
//            if (o == null || getClass() != o.getClass())
//                result = false;
//            else{
//                Personne personne = (Personne) o;
//                result = (age == personne.age && nom.equals(personne.nom) && prenom.equals(personne.prenom));
//            }
//        }
//        return result;
//    }

    @Override
    public String toString() {


        StringBuffer abuf;
        final StringBuilder sb = new StringBuilder("Personne{");
        sb.append("nom='").append(nom).append('\'');
        sb.append(", prenom='").append(prenom).append('\'');
        sb.append(", age=").append(age);
        sb.append('}');
        return sb.toString();
    }

    @Override
    public int compareTo(Personne o) {
        return this.nom.compareTo(o.nom);
    }
}
