package fr.formation;

import fr.formation.model.Personne;

public class TestEquals {
    public static void main(String[] args) throws CloneNotSupportedException {
        String s1 = "A";
        String s2 = new String("A");

        System.out.println(s1 == s2);
        System.out.println(s1.equals(s2));


        Personne p1 = new Personne(null, "Joe", 44);
        Personne p2 = new Personne("Legrand", "Joe", 44);

        System.out.println(p1 == p2);
//        System.out.println(p1.equals(p1));
        System.out.println(p1.equals(p2));
//        System.out.println(p1.equals("Toto"));

        String chaine2 = "Hello";
        String chaine = null;
        int aaa = 4;
        String result = aaa + chaine + aaa + chaine2 + aaa;
        System.out.println(result);
        int a = 12;
        int b = 32;
        int resultat = a * b;
        int resultatAttendu = 44;

        if (resultat != resultatAttendu){
            System.out.println(a + " + " + b + " devrait etre egal a " + resultatAttendu + " mais est egal à " + resultat);
        }

        Personne p3 = (Personne) p1.clone();

    }
}
