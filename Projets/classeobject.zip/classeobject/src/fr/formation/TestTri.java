package fr.formation;

import fr.formation.model.Personne;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class TestTri {

    public static void main(String[] args) {

        List<String> listeS = new ArrayList<>();
        listeS.add("d");
        listeS.add("a");
        listeS.add("v");
        listeS.add("i");
        listeS.add("r");
        listeS.add("c");
        System.out.println("\nListe non triée : ");
        listeS.forEach(s -> System.out.println(s));

        Collections.sort(listeS);
        System.out.println("\nListe  triée : ");
        listeS.forEach(s -> System.out.println(s));

        List<Integer> listeI = new ArrayList<>();
        listeI.add(5);
        listeI.add(3);
        listeI.add(1);
        listeI.add(4);
        listeI.add(2);
        System.out.println("\nListe non triée : ");
        listeI.forEach(i -> System.out.println(i));

        Collections.sort(listeI);
        System.out.println("\nListe  triée : ");
        listeI.forEach(i -> System.out.println(i));


        Personne p1 = new Personne("Legrand", "Joe", 44);
        Personne p2 = new Personne("Lepetit", "Suzon", 30);
        Personne p3 = new Personne("Lemoyen", "Anne", 55);

        List<Personne> listeP = new ArrayList<>();
        listeP.add(p2);
        listeP.add(p1);
        listeP.add(p3);

        System.out.println("\nListe non triée : ");
        listeP.forEach(p -> System.out.println(p));

        Collections.sort(listeP);
        System.out.println("\nListe triée : ");
        listeP.forEach(p -> System.out.println(p));


        Collections.sort(listeP, new Comparator<Personne>() {
            @Override
            public int compare(Personne o1, Personne o2) {
                return o2.getAge() - o1.getAge();
            }
        });


        System.out.println("\nListe triée par age décroissant : ");
        listeP.forEach(p -> System.out.println(p));
    }
}
