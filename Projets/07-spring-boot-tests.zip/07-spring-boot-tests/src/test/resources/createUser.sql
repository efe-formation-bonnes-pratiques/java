INSERT INTO Personne (nom, prenom, age) VALUES
  ('Legrand', 'Annie', 43),
  ('Lemoyen', 'Marco', 65);