package fr.formation.spring.bll;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import fr.formation.spring.dal.LivreDao;
import fr.formation.spring.entity.Livre;


@Service
public class LivreManager {
	
	@Autowired
	private LivreDao lDao;
	
	public void ajout(Livre l) throws Exception {
		if (l == null)
			throw new Exception("Livre nul");
		lDao.save(l);
	}
	
	public Livre trouver(int id) {
		Optional<Livre> trouveOpt = lDao.findById(id);
		if (trouveOpt.isPresent())
			return trouveOpt.get();
		else
			return null;
	}
	
	public List<Livre> liste() {
		return lDao.findAll();
	}

}


