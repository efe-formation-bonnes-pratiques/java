package fr.formation.spring.dal;

import org.springframework.data.jpa.repository.JpaRepository;

import fr.formation.spring.entity.Livre;

public interface LivreDao extends JpaRepository<Livre, Integer> {

}
