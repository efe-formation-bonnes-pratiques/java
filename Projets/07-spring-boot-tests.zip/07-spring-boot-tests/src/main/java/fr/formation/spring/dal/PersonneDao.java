	package fr.formation.spring.dal;
	
	import java.util.List;
	
	import org.springframework.data.jpa.repository.JpaRepository;
	import org.springframework.data.jpa.repository.Query;
	
	import fr.formation.spring.entity.Personne;
	
	public interface PersonneDao extends JpaRepository<Personne, Integer> {
	
		
		@Query("select p from Personne p order by p.nom")
		List<Personne> trouverTous();
		
		@Query("select p from Personne p WHERE p.nom = :nom")
		List<Personne> trouverParNom(String nom);
		
	}

	
	