package fr.formation.dp.builder;

public class Personne {

    private String nom;
    private String prenom;

    public Personne() {}

    public static PersonneBuilder builder(){
        return new PersonneBuilder();
    }


    public static class PersonneBuilder{
        private Personne personne;

        public PersonneBuilder() {
            personne = new Personne();
        }

        public PersonneBuilder nom(String nom){
            personne.nom = nom;
            return this;
        }

        public PersonneBuilder prenom(String prenom){
            personne.prenom = prenom;
            return this;
        }
        public Personne build(){
            return personne;
        }
    }


    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Personne{");
        sb.append("nom='").append(nom).append('\'');
        sb.append(", prenom='").append(prenom).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
