package fr.formation.dp.factory.metier;

import fr.formation.dp.factory.repository.DaoFactory;
import fr.formation.dp.factory.repository.LivreDao;

import java.util.List;

public class LivreService {

    private LivreDao livreDao;

    public LivreService() {
        this.livreDao = DaoFactory.getLivreDao();
    }

    public void ajouterLivre(Object livre){
        livreDao.add(livre);
    }

    public List<Object> trouverLivres(){
        return livreDao.findAll();
    }
}
