package fr.formation.dp.singleton;

public class AppelSingleton {

    public static void main(String[] args) {
/*
        MySingleton m1 = new MySingleton();
        MySingleton m2 = new MySingleton();

        System.out.println(m1);
        System.out.println(m2);
        System.out.println(m1 == m2);

 */

        MySingleton m1 = MySingleton.getInstance();
        MySingleton m2 = MySingleton.getInstance();
        System.out.println(m1);
        System.out.println(m2);
        System.out.println(m1 == m2);
    }
}
