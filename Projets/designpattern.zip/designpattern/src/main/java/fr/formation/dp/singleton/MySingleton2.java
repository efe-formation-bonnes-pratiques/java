package fr.formation.dp.singleton;

public class MySingleton2 {
    private static MySingleton2 mySingleton;

    private MySingleton2(){}

    static {
        mySingleton = new MySingleton2();
    }

    public static MySingleton2 getInstance(){
        return mySingleton;
    }
}
