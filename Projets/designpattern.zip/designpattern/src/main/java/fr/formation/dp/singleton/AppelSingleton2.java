package fr.formation.dp.singleton;

public class AppelSingleton2 {

    public static void main(String[] args) {


        MySingleton2 m1 = MySingleton2.getInstance();
        MySingleton2 m2 = MySingleton2.getInstance();
        System.out.println(m1);
        System.out.println(m2);
        System.out.println(m1 == m2);
    }
}
