package fr.formation.dp.factory.repository;

public class DaoFactory {

    public static LivreDao getLivreDao(){
        return new LivreDaoJdbc();
    }
}
