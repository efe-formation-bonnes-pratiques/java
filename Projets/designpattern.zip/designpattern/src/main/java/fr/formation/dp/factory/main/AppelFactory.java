package fr.formation.dp.factory.main;

import fr.formation.dp.factory.metier.LivreService;

public class AppelFactory {
    public static void main(String[] args) {

        LivreService livreService = new LivreService();
        livreService.trouverLivres();
    }
}
