package fr.formation.dp.builder;

public class AppelBuilder {
    public static void main(String[] args) {

        Personne p1 = Personne
                .builder()
                .nom("Legrand")
                .prenom("Luc")
                .build();

        Personne.PersonneBuilder pb = Personne.builder();
        pb.nom("Lepetit");
        pb.prenom("Suzanne");

        Personne p2 = pb.build();

        System.out.println(p1);
        System.out.println(p2);
    }
}
