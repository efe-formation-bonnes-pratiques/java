package fr.formation.dp.factory.repository;

import java.util.List;

public class LivreDaoExcel implements LivreDao{
    @Override
    public List<Object> findAll() {
        System.out.println("findAll de Excel");
        return null;
    }

    @Override
    public void add(Object livre) {
        System.out.println("add de Excel");

    }
}
