package fr.formation.dp.factory.repository;

import java.util.List;

public class LivreDaoJdbc implements LivreDao{
    @Override
    public List<Object> findAll() {
        System.out.println("findAll de Jdbc");
        return null;
    }

    @Override
    public void add(Object livre) {
        System.out.println("add de Jdbc");
    }
}
