package fr.formation.dp.factory.repository;

import java.util.List;

public interface LivreDao {

    List<Object> findAll();
    void add(Object livre);
}
