package fr.formation.metier;

import fr.formation.Personne;
import fr.formation.repository.PersonneRepository;

import java.util.List;

public class PersonneService {

    private PersonneRepository personneRepository;

    public PersonneService(PersonneRepository personneRepository) {
        this.personneRepository = personneRepository;
    }

    public void ajouterPersonne(Personne p){
        // Vérification que le nom n'est pas nul ...
        // Regles métier

        personneRepository.add(p);
    }

    public List<Personne> listerPersonnes(){
        return personneRepository.findAll();
    }
}
